INSERT INTO whsakila2021.store (store_id,nama_kota) VALUES
	 (1,'Lethbridge'),
	 (2,'Woodridge');